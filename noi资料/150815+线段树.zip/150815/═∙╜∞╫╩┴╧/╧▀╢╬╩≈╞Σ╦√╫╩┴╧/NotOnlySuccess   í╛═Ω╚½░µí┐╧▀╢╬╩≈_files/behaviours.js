jQuery(document).ready(function() {
  jQuery('.friend-info').cluetip({sticky: true, closePosition: 'title', arrows: true, activation: 'click', width: '310'});
});