#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;
char puzzle[30][30];
const int maxn = 729*4+100;
int sz;
int s[maxn];
int R[maxn],L[maxn],D[maxn],U[maxn];
int row[maxn], col[maxn];
int ansd, ans[maxn];
void init(int c)
{
    for(int i=0; i<=c; i++)
    {
        U[i] = i;
        D[i] = i;
        L[i] = i-1;
        R[i] = i+1;
    }
    R[c] = 0;
    L[0] = c;
    sz = c+1;
    memset(s,0,sizeof(s));
}
addrow(int r, int tmp[], int size)
{
    int first = sz;
    for (int i=0; i<size; i++)
    {
        int c = tmp[i];
        L[sz] = sz - 1;
        R[sz] = sz +1;
        D[sz] = c;
        U[sz] = U[c];
        D[U[c]] = sz;
        U[c] = sz;
        row[sz] = r;
        col[sz] = c;
        s[c]++;
        sz++;
    }
    L[first] = sz - 1;
    R[sz-1] = first;
}
#define FOR(i,A,s) for(int i=A[s]; i != s; i = A[i])
void remove(int c)
{
    L[R[c]] = L[c];
    R[L[c]] = R[c];
    FOR(i,D,c)
    FOR(j,R,i)
    {
        D[U[j]] = D[j];
        U[D[j]] = U[j];
        s[col[j]]--;
    }
}
void restore(int c)
{
    FOR(i,U,c)
    FOR(j,L,i)
    {
        s[col[j]]++;
        U[D[j]] = j;
        D[U[j]] = j;
    }
    L[R[c]] = c;
    R[L[c]] = c;
}
bool dfs(int d)
{
    if(R[0]==0)
    {
        ansd = d;
        return true;
    }

    int c = R[0];

    FOR(i,R,0) if(s[i]<s[c]) c = i;

    remove(c);
    FOR(i,D,c)
    {
        ans[d] = row[i];
        FOR(j,R,i) remove(col[j]);
        if(dfs(d+1)) return true;
        FOR(j,L,i) restore(col[j]);
    }
    restore(c);

    return false;
}
int main()
{
    int t;
    while(1)
    {
        char c = getchar();
        if(c=='e') break;
        for (int i=0; i<9; i++)
        {
            for (int j=0; j<9; j++)
                if(i==0 && j==0) puzzle[i][j] = c;
                else scanf("%c",&puzzle[i][j]);
        }
        getchar();
        init(324);
        for (int r=0; r<9; r++)
        {
            for (int c=0; c<9; c++)
            {
                for (int v=0; v<9; v++)
                {
                    if(puzzle[r][c]=='.' || puzzle[r][c]== '1'+v)
                    {
                        int tmp[1000];
                        int size = 0;
                        tmp[size++] = r*9 + c+1;                                // ÿһ����ֻ����һ����
                        tmp[size++] = 81 + r*9+v+1;                             // ÿ��
                        tmp[size++] = 81*2 + c*9+v+1;                           // ÿ��
                        tmp[size++] = 81*3 + ((r/3)*3+c/3)*9+v+1;               // ÿ���Ź���
                        addrow(r*81+c*9+v+1,tmp,size);
                    }
                }
            }
        }
        dfs(0);
        for (int i=0; i<ansd; i++)
        {
            int r,c,v;
            int num = ans[i]-1;
            v = num % 9;
            num /= 9;
            c = num % 9;
            num /= 9;
            r = num;
            puzzle[r][c] = '1'+v;
        }
        for (int i=0; i<9; i++)
        {
            for (int j=0; j<9; j++)
                printf("%c",puzzle[i][j]);
        }
        printf("\n");
    }
    return 0;
}
