//zoj 3209
#include<cstdio>
#include<iostream>
#include<cstring>
#define inf 999999999
using namespace std;
int n,m,p;
const int max_node = 500000;
const int max_row = 505;
int U[max_node],D[max_node],R[max_node],L[max_node];    // ʮ������
int S[max_node];                                        //���н����
int ans[max_row],ansd;                                  //�⣬�ⳤ�ȣ�������
int col[max_node],row[max_node];                        // ���б��
int r,c;
int sz;                                                 // �������
void init()
{
    //������ͷ���
    for(int i=0; i<=c; i++)
    {
        D[i]=i;U[i]=i;
        R[i]=i+1;L[i]=i-1;
    }
    L[0]=c,R[c]=0;
    sz = c+1;
    memset(S,0,sizeof(S));

}
void addrow(int tmp[], int size, int r)
{

    int first = sz;
    for (int i=0; i<size; i++)
    {
        int c = tmp[i];
        L[sz] = sz-1;R[sz] = sz+1;
        D[sz] = c; U[sz] = U[c];
        D[U[c]] = sz; U[c] = sz;
        row[sz] = r;col[sz] = c;
        S[c]++;
        sz++;
    }
    R[sz-1] = first;
    L[first] = sz-1;
}
#define FOR(i,A,s) for(int i=A[s]; i != s; i = A[i])
void remove(int c)                     //ɾ��c�У��Լ�c����Ϊ1����Щ��
{
    L[R[c]] = L[c];
    R[L[c]] = R[c];
    FOR(i,D,c)
        FOR(j,R,i)
        {
            U[D[j]] = U[j];
            D[U[j]] = D[j];
            S[col[j]]--;
        }
}
void restore(int c)                  // ����ָ�
{

    FOR(i,U,c)
        FOR(j,L,i)
        {
            U[D[j]] = j;
            D[U[j]] = j;
            S[col[j]]++;
        }
    L[R[c]] = c;
    R[L[c]] = c;
}
void dfs(int cur)
{
    if(!R[0])
    {                                               // �ҵ���
        if(cur<ansd)                                // cur Ϊ��ĳ��ȣ��ݹ���ȡ����������
            ansd = cur;
        return ;
    }
    int c = R[0];
    FOR(i,R,0)                                      // �Ż���ѡ��1��������
    {
        if(S[c]>S[i]) c = i;
    }
    remove(c);
    FOR(i,D,c)
    {
        ans[cur] = row[i];
        FOR(j,R,i) remove(col[j]);                   // ɾ��ÿһ������1����Щ�С��Լ�ÿһ������1����Щ��
        dfs(cur+1);
        FOR(j,L,i) restore(col[j]);                  // ����
    }
    restore(c);
}
int main()
{
    int t;
    scanf("%d",&t);

    while(t--)
    {
        int x1,y1;
        int x2, y2;
        scanf("%d %d %d",&n,&m,&p);
        c = n*m;
        init();
        for(int k=1; k<=p; k++)
        {
            scanf("%d %d",&x1,&y1);
            scanf("%d %d",&x2,&y2);
            int tmp[1000];
            int size = 0;
            for(int i=x1; i<x2; i++)
                for(int j=y1; j<y2; j++)
                {
                    tmp[size++] = i*m+j+1;
                }
            addrow(tmp,size,k);

        }
        ansd = inf;
        dfs(0);
        if(ansd == inf) printf("-1\n");
        else printf("%d\n",ansd);
    }
}
